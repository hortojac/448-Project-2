#include <iostream>
#include "executive.h"

int main(){
    Executive exec; // creates an instance of the Executive class
    exec.run();
    return 0;
}
